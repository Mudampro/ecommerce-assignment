# product
# order
# customer


# customer - id, email, password, name
# product - id, name, price, quantity_available
# order id, customer_id, items[product_id]

