from fastapi import HTTPException
from schema.customer import customers


class UsernameCheck:
    @staticmethod
    def check_unique_username(username: str):
        if any(customer.username == username for customer in customers):
            raise HTTPException(status_code=400, detail= "Username already taken. Please choose a different username")
        return username
    
 
